"""
自动下载生成的图片到项目目录
使用方法：先运行 generate_images.py 生成图片，然后运行此脚本下载
"""
import os
import requests
from pathlib import Path

# 图片保存目录
OUTPUT_DIR = Path(__file__).parent.parent / "public" / "images" / "scenes"

def download_image(url, filename):
    """下载单张图片"""
    try:
        print(f"正在下载: {filename}")
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        # 确保目录存在
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        
        # 保存文件
        filepath = OUTPUT_DIR / filename
        with open(filepath, 'wb') as f:
            f.write(response.content)
        
        print(f"✅ 下载成功: {filepath}")
        return True
        
    except Exception as e:
        print(f"❌ 下载失败: {str(e)}")
        return False

def main():
    """主函数"""
    print("\n" + "="*60)
    print("图片自动下载工具")
    print("="*60 + "\n")
    
    # 生成的图片URL
    images = [
        ("prologue_bridge.png", "https://ark-content-generation-v2-cn-beijing.tos-cn-beijing.volces.com/doubao-seedream-4-5/0217749292540433f557f99638b5e18fc2ec2d6c4abb5d2bdc02d_0.jpeg?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260331%2Fcn-beijing%2Ftos%2Frequest&X-Tos-Date=20260331T035423Z&X-Tos-Expires=86400&X-Tos-Signature=e1e1b49cd76f8da326cde3106d370db925fbfe3122de4ffd510730921a5880cb&X-Tos-SignedHeaders=host"),
        ("chapter1_hut.png", "https://ark-content-generation-v2-cn-beijing.tos-cn-beijing.volces.com/doubao-seedream-4-5/0217749292658823f557f99638b5e18fc2ec2d6c4abb5d2ae7c3f_0.jpeg?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260331%2Fcn-beijing%2Ftos%2Frequest&X-Tos-Date=20260331T035434Z&X-Tos-Expires=86400&X-Tos-Signature=6db59e0d646b96b016864890ea3b84d189681e0bb5f526b28cd2564adf6d6910&X-Tos-SignedHeaders=host"),
        ("chapter2_forge.png", "https://ark-content-generation-v2-cn-beijing.tos-cn-beijing.volces.com/doubao-seedream-4-5/0217749292762543f557f99638b5e18fc2ec2d6c4abb5d2cb073f_0.jpeg?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260331%2Fcn-beijing%2Ftos%2Frequest&X-Tos-Date=20260331T035444Z&X-Tos-Expires=86400&X-Tos-Signature=c18e71f323fca58c576013f3537f93495d157e0a48d63a8b440878c986d7b954&X-Tos-SignedHeaders=host"),
        ("chapter3_lamppost.png", "https://ark-content-generation-v2-cn-beijing.tos-cn-beijing.volces.com/doubao-seedream-4-5/0217749292867183f557f99638b5e18fc2ec2d6c4abb5d2bfbb5b_0.jpeg?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260331%2Fcn-beijing%2Ftos%2Frequest&X-Tos-Date=20260331T035456Z&X-Tos-Expires=86400&X-Tos-Signature=edf54f25317f3ae7d62b5c715a8e50a2da3ad042c1109134b68370c859def2b4&X-Tos-SignedHeaders=host"),
        ("ending_hope.png", "https://ark-content-generation-v2-cn-beijing.tos-cn-beijing.volces.com/doubao-seedream-4-5/0217749292981883f557f99638b5e18fc2ec2d6c4abb5d2e29b27_0.jpeg?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260331%2Fcn-beijing%2Ftos%2Frequest&X-Tos-Date=20260331T035507Z&X-Tos-Expires=86400&X-Tos-Signature=c02a8d6e2cd78472029be9154fe2fe4b5e339ed1445a74b686dbbf93f4853a96&X-Tos-SignedHeaders=host"),
    ]
    
    if not images:
        print("⚠️  请先运行 generate_images.py 生成图片")
        print("然后将输出的URL复制到此脚本的 images 列表中\n")
        print("格式示例：")
        print('images = [')
        print('    ("prologue_bridge.png", "https://your-image-url-1"),')
        print('    ("chapter1_hut.png", "https://your-image-url-2"),')
        print(']\n')
        return
    
    success_count = 0
    for filename, url in images:
        if download_image(url, filename):
            success_count += 1
    
    print("\n" + "="*60)
    print(f"下载完成: {success_count}/{len(images)} 张图片")
    print(f"保存位置: {OUTPUT_DIR.absolute()}")
    print("="*60 + "\n")

if __name__ == "__main__":
    main()
